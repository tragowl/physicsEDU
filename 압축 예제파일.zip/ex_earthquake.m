clc; clear;

fs = 20000;

t = 0 : 1/fs : 5 ;

f1 = 20;
f2 = 7.5;

y = 1.5*exp(-0.2*t).*sin(2*pi*f1*(t-pi/4)) + 3*exp(-0.4*t).*sin(2*pi*f2*(t+pi/6))  ;


figure()
subplot(2,1,1)
plot(t,y)

subplot(2,1,2)
t_sampled = t(1:100:end) ;
y_sampled = y(1:100:end) ;
plot(t_sampled,y_sampled)