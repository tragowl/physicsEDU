clc; clear; close all;

Data = importdata("spectrum.csv");
data = Data.data ;

n1 = 1500
n2 = length(data(:,1))

pix = data(n1:n2, 1) ;
Hydrogen = data(n1:n2,2) ;
Sun = data(n1:n2,3) ;
pix = pix - pix(1) + 1 ;

subplot(2,1,1)
plot(pix,Hydrogen, pix, Sun)
legend("수소선","태양흡수선")
xlabel("픽셀넘버");
ylabel("세기")
title("태양광 스펙트럼")
grid on
n1 = 663; lambda1 = 486;
n2 = 1502; lambda2 = 656;
lambda = ((lambda2 - lambda1)*(pix - n1 ) /(n2 - n1)) + lambda1 ;

subplot(2,1,2)
plot(lambda,Hydrogen)
hold on
plot(lambda,Sun)
legend("수소선","태양흡수선")
xlabel("파장(nm)");
ylabel("세기")
title("태양광 스펙트럼")
grid on

Data_regeration = [lambda Hydrogen Sun] ;

