%% 인간과 좀비의 대결

clc; clear; close all; 

H = 500;
Z = 30;

t = 0:1:100;

a = 0.3*(1 - exp(-0.5*t)); % 감염률    시간에 따른 향상
b = 0.5*(1 - exp(-0.06*t)) ; % 처치율  시간에 따른 향상
c = 0.01*(1 - exp(-t)) ; % 좀비 자연사율 시간에 따른 감소

for k=1:length(t)-1
    interaction(k) = H(k)*Z(k)/( H(k)+Z(k) ) ;
    dH =  - a(k)*interaction(k) ;
    dZ = (a(k)-b(k))*interaction(k) - c(k)*Z(k) ;

    H(k+1) = H(k) + dH;
    Z(k+1) = Z(k) + dZ ; 
end

plot(t,H,t,Z,LineWidth = 3)
legend("Human", "Zombie")
grid on;
xlabel("시간")
ylabel("개체수")
grid on