%% 인간과 좀비의 대결

clc; clear; close all; 

H = 500;
Z = 30;

t = 0:1:100;

a = 0.3; % 감염률 
b = 0.2 ; % 처치율

for k=1:length(t)-1
    interaction(k) = H(k)*Z(k)/( H(k)+Z(k) ) ;
    dH =  - a*interaction(k) ;
    dZ = (a-b)*interaction(k)  ;

    H(k+1) = H(k) + dH;
    Z(k+1) = Z(k) + dZ ; 
end

plot(t,H,t,Z,LineWidth = 3)
legend("Human", "Zombie")
grid on;
xlabel("시간")
ylabel("개체수")
grid on