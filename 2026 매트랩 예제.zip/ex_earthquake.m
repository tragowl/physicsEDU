clc; clear;

fs = 200;

t = 0 : 1/fs : 5 ;

f1 = 20;
f2 = 7.5;

y = 1.5*exp(-0.2*t).*sin(2*pi*f1*(t-pi/4)) + 3*exp(-0.4*t).*sin(2*pi*f2*(t+pi/6)) ;
% 스파이크 노이즈 추가 예시
spike_noise = zeros(size(t));
spike_idx = randperm(length(t), 350); % 전체 데이터 중 무작위 20곳
spike_noise(spike_idx) = (rand(1, 350) - 0.5) * 2; % -1 ~ 1 사이의 튀는 값
y = y + spike_noise;
D = [t' y'];

figure()

plot(t,y)
