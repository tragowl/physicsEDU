clc; clear; clf; close all;

x = -2:0.02: 2;
y1 = 8*x - 20 ;
y2 = -2*x.^2 + 10*x + 1;
y3 = 6*sin(2*pi*2*x) ;
y4 = x./(1-x.^2) ;
y5 = 2.^(x) ;
y6 = 5*exp(-2*x.^2) ;

figure()
hold on
plot(x, y1, LineWidth=2)
plot(x, y2, 'X')
plot(x, y3, LineWidth = 5)
plot(x, y4)
plot(x, y5)
plot(x, y6)

grid on
xlabel("x")
ylabel("y")
title("그래프 연습")
legend("y1","y2","y3","y4","y5","y6")