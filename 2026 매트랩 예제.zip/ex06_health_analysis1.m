%% 빅데이터 분석 및 데이터간 변환관계 분석 예제

clc; clear; clf; close;

D = importdata("health_data.xlsx");
Data = D.data;
class = D.textdata(1,1:7);
state = D.textdata(2:end,8);

X1 = Data(1:end, 1:5); % 학습용 입력 데이터
Y1 = Data(1:end, 6:end); % 학습용 출력 데이터

M = pinv(X1)*Y1 % 데이터 사이 가중치

X_my = [ 2 18 6 0.2 2100] ; % 나의 성별, 나이, 수면, 운동, 식사량

prediction = X_my*M

