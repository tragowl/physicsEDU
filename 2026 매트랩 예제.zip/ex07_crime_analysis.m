%% 범죄 장소와 요일간 관계성 분석

clc; clear; close; 

D1 = importdata("crime_loc.xlsx") ;
D2 = importdata("crime_day.xlsx") ;

class_loc = D1.textdata(1, 2:end) ;
class_day = D2.textdata(1, 2:end) ;

murder_loc = D1.data(4, 1:end );
murder_day = D2.data(4, 1:end) ;

figure()
subplot(2,1,1)
M1 = pinv(murder_day)*murder_loc 
heatmap(class_loc,class_day,M1)
colormap("turbo")
title("살인사건 장소에 대한 요일 가중치")

sexual_loc = D1.data(7, 1:end );
sexual_day = D2.data(7, 1:end) ;

subplot(2,1,2)
M2 = pinv(sexual_day)*sexual_loc 
heatmap(class_loc,class_day,M2)
colormap("turbo")
title("성범죄 장소에 대한 요일 가중치")

figure()

fire_loc = D1.data(6, 1:end );
fire_day = D2.data(6, 1:end) ;

subplot(2,1,1)
M3 = pinv(fire_day)*fire_loc 
heatmap(class_loc,class_day,M3)
colormap("turbo")
title("방화 사건 장소에 대한 요일 가중치")

damage_loc = D1.data(3, 1:end );
damage_day = D2.data(3, 1:end) ;

subplot(2,1,2)
M4 = pinv(damage_day)*damage_loc 
heatmap(class_loc,class_day,M4)
colormap("turbo")
title("손괴 사건 장소에 대한 요일 가중치")
