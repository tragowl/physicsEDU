clc; clear; close all; clf;

h = 0.01 ;
t = 0:h:10;

vz = 5*t ;
vx = 2*t.*cos(2*pi*2*t) ;
vy = 2*t.*sin(2*pi*3*t) ;
x = 0; y = 0 ; z= 0;

for j=1:length(t)-1
    x(j+1) = x(j) + h*vx(j);
    y(j+1) = y(j) + h*vy(j);
    z(j+1) = z(j) + h*vz(j);
end

plot3(x,y,z,LineWidth = 3)
grid on
xlabel("x")
ylabel("y")
zlabel("z")
title("파리의 비행궤적")