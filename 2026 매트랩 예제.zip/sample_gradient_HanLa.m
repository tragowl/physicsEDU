%% 1. 데이터 로드 및 단위 확인
filename = 'halla_data.csv';
data = readmatrix(filename);

% NaN 값 제거
data(any(isnan(data), 2), :) = [];

X_raw = data(:,1);
Y_raw = data(:,2);
Z_raw = data(:,3);

% 고도가 지나치게 높거나 0인 노이즈 제거 (한라산 높이 1947m 기준)
valid_idx = Z_raw > 10 & Z_raw < 2000; 
X_raw = X_raw(valid_idx);
Y_raw = Y_raw(valid_idx);
Z_raw = Z_raw(valid_idx);

%% 2. 데이터 범위 강제 제한 (메모리 방어)
% 전체를 다 그리지 않고, 데이터가 모여 있는 중심부만 추출합니다.
% 만약 에러가 계속나면 이 범위를 더 좁히세요.
x_center = median(X_raw);
y_center = median(Y_raw);
range_val = 10000; % 중심으로부터 사방 5km만 일단 보기

crop_idx = X_raw > (x_center - range_val) & X_raw < (x_center + range_val) & ...
           Y_raw > (y_center - range_val) & Y_raw < (y_center + range_val);

X_raw = X_raw(crop_idx);
Y_raw = Y_raw(crop_idx);
Z_raw = Z_raw(crop_idx);

%% 3. 격자 생성 (간격 상향 조정)
% 처음에는 100m로 시도해서 돌아가는지 확인 후 50m로 줄이세요.
grid_step = 200; 
xq = min(X_raw):grid_step:max(X_raw);
yq = min(Y_raw):grid_step:max(Y_raw);

% 행렬 크기 사전 체크
if length(xq) * length(yq) > 1e7
    error('행렬이 너무 큽니다! grid_step을 더 키우거나 범위를 줄이세요.');
end

[X, Y] = meshgrid(xq, yq);

%% 4. 지형 보간 (Linear 방식이 메모리를 적게 먹습니다)
disp('지형 보간 중...');
F = scatteredInterpolant(X_raw, Y_raw, Z_raw, 'linear');
Z = F(X, Y);

%% 5. 시각화
figure('Color', 'w');
mesh(X, Y, Z); % surf보다 mesh가 가볍습니다
view(3);
title(['한라산 최적화 모델 (간격: ', num2str(grid_step), 'm)']);

%% 3. 경사하강법 시뮬레이션 (수정 버전)
[dZdx, dZdy] = gradient(Z, grid_step); 

num_particles = 40; % 갯수를 조금 더 늘림
hold on;

% 시작점 필터링 (NaN이 아니고 고도가 적당히 높은 곳)
valid_z_idx = find(~isnan(Z) & Z > 1000); 

if isempty(valid_z_idx)
    error('시작 지점을 찾을 수 없습니다. 고도 제한(800)을 낮춰보세요.');
end

start_indices = valid_z_idx(randi(length(valid_z_idx), num_particles, 1));

for p = 1:num_particles
    [r, c] = ind2sub(size(Z), start_indices(p));
    currX = X(r, c);
    currY = Y(r, c);
    
    path = [currX, currY, Z(r, c)];
    
    % --- 중요 수정 사항 ---
    % 1. step_size를 크게 키움 (격자 간격이 200m이므로 최소 50~100은 이동해야 함)
    % 2. 단순히 기울기만 쓰는게 아니라 방향(Unit Vector)을 추출해서 일정한 거리만큼 이동
    move_dist = 150; % 한 번에 150m씩 이동
    
    for i = 1:200 % 이동 횟수도 늘림
        gx = interp2(X, Y, dZdx, currX, currY);
        gy = interp2(X, Y, dZdy, currX, currY);
        
        if isnan(gx) || isnan(gy), break; end
        
        % 기울기의 크기(경사도)
        grad_norm = sqrt(gx^2 + gy^2);
        if grad_norm < 0.001, break; end % 평지에 도달
        
        % 단위 벡터 방향으로 일정 거리 이동
        currX = currX - (gx / grad_norm) * move_dist;
        currY = currY - (gy / grad_norm) * move_dist;
        
        % 현재 위치 높이 계산
        currZ = interp2(X, Y, Z, currX, currY);
        if isnan(currZ), break; end
        
        path = [path; currX, currY, currZ];
    end
    
    % 궤적이 지형에 파묻히지 않게 Z축으로 20m 띄움 (+20)
    % 색상을 빨간색('r')으로 바꿔서 더 잘 보이게 함
    if size(path, 1) > 1
        plot3(path(:,1), path(:,2), path(:,3) + 20, 'r', 'LineWidth', 2);
    end
end
hold off;
title('한라산 지형 및 경사하강 궤적 (빨간선)');