%% 빅데이터 분석 및 데이터간 변환관계 분석 예제

clc; clear; clf; close;

D = importdata("health_data.xlsx");
Data = D.data;
class = D.textdata(1,1:7);
state = D.textdata(2:end,8);

X1 = Data(1:17, 1:5); % 학습용 입력 데이터
Y1 = Data(1:17, 6:7); % 학습용 출력 데이터

M = pinv(X1)*Y1 % 학습용 입,출력 데이터 간 변환행렬

X2 = Data(18:end, 1:5); % 테스트 입력 데이터
Y2 = Data(18:end, 6:7); % 테스트 원본 출력 데이터
pred_Y2 = X2*M ;        % 학습 데이터 기반 테스트 입력 데이터로 출력 예측
error = Y2 - pred_Y2 ;  % 실제 데이터와 예측 데이터간 차이
rmse = sqrt( mean(error).^2 ) % 체중, 혈압에 대한 rmse 에러 계산

figure()
subplot(2,1,1)
scatter(Y2(:,1),pred_Y2(:,1))
hold on
plot(Y2(:,1),Y2(:,1))
title("실제 체중와 예측 체중")
xlabel("실제 체중")
ylabel("예측 체중")

subplot(2,1,2)
scatter(Y2(:,2), pred_Y2(:,2))
hold on
plot(Y2(:,2),Y2(:,2))
title("실제 혈압과 예측 혈압")
xlabel("실제혈압")
ylabel("예측혈압")

