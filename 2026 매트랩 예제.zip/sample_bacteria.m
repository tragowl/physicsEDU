clc; clear; close;

N = 3000;               % 초기 세균 수
R = 0.5;                 % 항생제 내성 비율
N_im = N * R;             % 항생제 내성 세균 수
N_nim = N * (1 - R);      % 항생제 내성 없는 세균 수
r_im = 0.45;               % 내성 세균에 대한 항생제 효과율(치사율)
r_nim = 0.55;              % 비내성 세균에 대한 항생제 효과율(치사율)
g = 2 ;                  % 세균 증식률

x_min = 0; 
x_max = 1000;
y_min = 0;
y_max = 1000;
t = 0:1:50;

% GIF 파일을 저장할 경로
gif_filename = 'bacteria_growth3.gif';

for k = 1:length(t)-1    
    % 내성균과 비내성균의 수 갱신
    N_im(k+1) = round(N_im(k)*(1 - r_im) *g);  % 
    N_nim(k+1) = round(N_nim(k)*(1 - r_nim) *g);
    N(k+1) = N_im(k+1) + N_nim(k+1);
    
    % 랜덤 좌표 생성
    x_im = (x_max - x_min) * rand(N_im(k), 1) + x_min;
    y_im = (y_max - y_min) * rand(N_im(k), 1) + y_min;
    x_nim = (x_max - x_min) * rand(N_nim(k), 1) + x_min;
    y_nim = (y_max - y_min) * rand(N_nim(k), 1) + y_min;

    % 그래프 그리기
    scatter(x_im, y_im, 'red','filled');
    hold on;
    scatter(x_nim, y_nim, 'blue','filled');
    xlim([x_min, x_max]);
    ylim([y_min, y_max]);
    title(['시간: ' num2str(k)]);
    legend("내성균", "비내성균");
    set(gca, 'xtick', []);   % x축 숫자 제거
    set(gca, 'ytick', []);   % y축 숫자 제거
    pause(0.01)

    % 그래프 프레임을 캡처하여 GIF로 저장
    frame = getframe(gcf);          % 현재 그림을 프레임으로 캡처
    im = frame2im(frame);           % 프레임을 이미지로 변환
    [imind, cm] = rgb2ind(im, 256); % 이미지를 인덱스 색상으로 변환
    
    if k == 1
        % GIF 파일을 새로 생성 (첫 번째 프레임일 때)
        imwrite(imind, cm, gif_filename, 'gif', 'LoopCount', Inf, 'DelayTime', 0.5);
    else
        % 기존 GIF에 추가 (두 번째 프레임부터)
        imwrite(imind, cm, gif_filename, 'gif', 'WriteMode', 'append', 'DelayTime', 0.5);
    end
    
    hold off; % 그래프 초기화
end
