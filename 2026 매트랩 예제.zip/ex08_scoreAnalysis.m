%% 성적 분석

clc; clear;  clf; close all

D = importdata("score_data.xlsx")
score = D.data;
subject = D.textdata(1, 2:8);
ID = D.textdata(2:end, 1);

%% 최고 성적 뽑기

[maxScore maxID] = max(score)
avg = mean(score)

%% 성적 분포 시각화 분석
figure()
heatmap(subject, ID, score)

figure()
bar3(score)
title("학생별 성적 분포표")

%% 국어 교과와 다른 교과 성적간의 구조관계

X = score(:,2:end) ; % 국어 외 다른 교과 성적 데이터
Y = score(:,1); % 국어 교과 성적

M = pinv(X)*Y % 국어외 교과 성적이 국어 교과에 미치는 가중치 계수

heatmap(subject(1), subject(2:end), M)
