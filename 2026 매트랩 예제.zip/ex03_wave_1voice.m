clc; clear;

%% 외부 음원 파일 불러오기 
VData = importdata("myvoice.m4a") ;  %%  importdata 명령어, 파일 변경 가능
Y = VData.data ;                             %% 가져온 데이터의 구조(struct)에 따른 데이터 주소
fs = VData.fs ;                                %% 가져온 데이터의 구조(struct)에 따른 데이터 주소

%% 샘플링 주파수로부터 시간 도메인 만들기
T=  0 : 1/fs : (1/fs)*(length(Y)-1 )  ;

%% 분석 구간 데이터 인덱스 설정
N1 = 1 ;   % Y 에서 분석 구간 시작 인덱스
N2 = length(Y) ;   % Y 에서 분석 구간 종료 인덱스

%% 분석 구간 데이터 그래프 플롯
t= T(N1:N2);     % 시간 분석 구간 정의
Y_interval = Y(N1:N2);    % 신호 분석 구간의 정의

plot(t,Y_interval)
grid on
title("Signal on Time")
xlabel("time(s)")
ylabel("amplitude")

