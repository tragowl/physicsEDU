clc; clear; close all;

D = importdata("sesimic_wave.xlsx");
Fs = 200;

t = D.data(2:end, 1) ;
y = D.data(2:end, 2) ;
plot(t, y)