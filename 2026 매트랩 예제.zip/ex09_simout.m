clc;
t = out.simout.Time ;
data = out.simout.Data ;

plot(t,data(:,1), t, data(:,2))
