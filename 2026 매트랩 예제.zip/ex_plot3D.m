clc; clear; close all;

a = -3*pi:0.3 : 3*pi;
[x y] = meshgrid(a,a);

z1 = x.^2 - y.^2 ;
z2 = 5*exp(-x.^2 - y.^2) + 2*exp(-(x-6).^2 - (y-5).^2) - 3*exp(-(x+3).^2 - (y+3).^2);

figure()
mesh(x,y,z1)

figure()
surf(x,y,z2)

figure()
bar3(z2)