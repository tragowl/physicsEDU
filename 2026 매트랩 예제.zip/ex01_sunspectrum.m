%% 태양 스펙트럼 사진 분석

clc; clear; clf; close all;

D = importdata("Sun.csv")
data = D.data;
pix = data(:,1);
gray = data(:,2);

plot(pix,gray)
refpix1 = 1867; % 기준 픽셀 -> 파장 434nm
refpix2 = 2978; % 기준 픽셀 -> 파장 656nm
lambda = 434 + (pix - refpix1)*(656 - 434)/(refpix2 - refpix1) ;

figure()
plot(lambda, gray, LineWidth = 2.5)
axis([300 750 0 100])
grid on
title("태양 흡수 스펙트럼 분석")
xlabel("파장(nm)")
ylabel("상대세기")

% 주요 흡수 피크선 파장 분석해보자.