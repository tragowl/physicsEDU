%% 누가 빵을 제일 많이 먹을까?

clc; clear; clf; close all;

N = 500 ; % 초기 빵의 개수
S = 1:100; % 학생 

for k= 1:length(S)
    myFood(k) = N(k)*(k/100) ;
    N(k+1) = N(k) - myFood(k) ;
end

subplot(2,1,1)
plot(S,myFood)
xlabel("학생")
ylabel("가져간 빵")
grid on

subplot(2,1,2)
plot(S,N(1:100))
xlabel("학생")
ylabel("빵의 잔량")
grid on


